﻿using Epione.Domain.Entities;
using Service.Pattern;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Epione.Data.Infrastructures;

using System.Collections;
using System.IO;

namespace Epione.Service
{
    public class GestionDoctor : GestionService<Doctor>, IGestionDoctor
    {
        public static DatabaseFactory dbFactory = new DatabaseFactory();
        public static UnitOfWork utw = new UnitOfWork(dbFactory);
        public GestionDoctor() : base(utw)
        {
        }
        public void ValiderDoctor(Doctor d)
        {
            d.validation = validation.ComptesValidés;
            MisAjour(d);
        }
        /*public int ComparerDoctor(string name)
        {
            int x = 0;
            var feed = FeedReader.Read("https://politepol.com/feed/33957?fbclid=IwAR04BxPZ3X-kLZjBe-EEKbk_R5m5yDFuo6HAYZfQRrkvmG72zeJUwmKEh8A");
            foreach (var item in feed.Items)
            {
                if (item.Description.ToString().Equals(name))
                {
                    x = 1;
                }                
            }
            return x;
        }*/
        public int ComparerDoctor(string name)
        {
            int x = 0;
            StreamReader Sw = new StreamReader("C:/Users/esprit/Desktop/Epione/Epione/bin/Debug/Doctolib.txt");
            name = "Dr Maelle Perron Médecin généraliste";
            for (int i = 0; i < File.ReadLines("C:/Users/esprit/Desktop/Epione/Epione/bin/Debug/Doctolib.txt").Count(); i++)
            {
                if (name.Equals(Sw.ReadLine().ToString()))
                {
                    x = 1;
                }
            }
            return x;
        }
    }
}
