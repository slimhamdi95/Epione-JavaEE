﻿using Epione.Data.Infrastructures;
using Epione.Domain.Entities;
using Service.Pattern;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Epione.Service
{
    public class GestionAvailability : GestionService<Availability>
    {
        public static DatabaseFactory dbFactory = new DatabaseFactory();
        public static UnitOfWork utw = new UnitOfWork(dbFactory);

        public GestionAvailability() : base(utw)
        {

        }
       
    }
}
